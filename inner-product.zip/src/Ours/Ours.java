package Ours;


import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import it.unisa.dia.gas.plaf.jpbc.pairing.a.TypeACurveGenerator;

import java.io.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import java.util.Properties;
import java.util.Random;


import static java.lang.System.out;
import static java.lang.System.setOut;


public class Ours {

    //初始阶段


    public static void setup(String pairingFile, String paramsFile,String mskFile,int t) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G1或者G2元素的对象
        Properties PProp =loadPropFromFile(paramsFile);
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        //调用两次setup函数为了不代替之前的数据，用loadPropFromFile打开文件并直接取其中数据
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置主私钥
        Element  s = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element[] A = new Element[t];
        for (int i = 1; i <= t-1; i++)
        {
            A[i] = bp.getZr().newRandomElement().getImmutable();
            PProp.setProperty("a"+i, A[i].toString());
        }
        Element P = g.powZn(s).getImmutable();


        Element e = bp.pairing(g,g);

        mskProp.setProperty("msk1", Base64.getEncoder().encodeToString(s.toBytes()));//element和string类型之间的转换需要通


        PProp.setProperty("g", g.toString());
        PProp.setProperty("e", e.toString());
        PProp.setProperty("P", P.toString());
        storePropToFile(PProp,paramsFile);

        storePropToFile(mskProp, mskFile);
    }

    public static void setup1(String pairingFile, String paramsFile,String mskFile) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G1或者G2元素的对象
        Properties PProp =loadPropFromFile(paramsFile);
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String hstr=PProp.getProperty("h");
        Element h = bp.getG1().newElementFromBytes(hstr.getBytes()).getImmutable();
        //调用两次setup函数为了不代替之前的数据，用loadPropFromFile打开文件并直接取其中数据
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置主私钥
        Element  alpha = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element  beta = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element g1 = g.powZn(alpha).getImmutable();
        Element h0 = h.powZn(beta).getImmutable();
        Element h1 = h.powZn(alpha).getImmutable();


        mskProp.setProperty("h", Base64.getEncoder().encodeToString(h.toBytes()));//element和string类型之间的转换需要通
        mskProp.setProperty("h0", Base64.getEncoder().encodeToString(h0.toBytes()));//element和string类型之间的转换需要通
        mskProp.setProperty("h1", Base64.getEncoder().encodeToString(h1.toBytes()));//element和string类型之间的转换需要通
        mskProp.setProperty("egh", Base64.getEncoder().encodeToString(bp.pairing(g,h).toBytes()));//element和string类型之间的转换需要通

        PProp.setProperty("g1", g1.toString());
        PProp.setProperty("egh0", bp.pairing(g,h0).toString());
        storePropToFile(PProp,paramsFile);

        storePropToFile(mskProp, mskFile);
    }


    public static void RSUKGen(String pairingFile, String paramsFile,String mskFile,String RSUi,String skFile,int t)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties mskProp = loadPropFromFile(mskFile);
        String msk1str = mskProp.getProperty("msk1");

        Element eRSU = bp.getZr().newElementFromBytes(RSUi.getBytes(StandardCharsets.UTF_8)).getImmutable();
        Element RSU = eRSU;
        Element[] A = new Element[t];
        Element fRSUi = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(msk1str)).getImmutable();
        for (int i = 1; i <= t-1; i++)
        {
            String astr = PProp.getProperty("a"+i);
            A[i] = bp.getZr().newElementFromBytes(astr.getBytes(StandardCharsets.UTF_8)).getImmutable();
            fRSUi = fRSUi.add(A[i].mulZn(RSU)).getImmutable();
            RSU = RSU.mulZn(RSU);
        }
        skProp.setProperty("rsk"+RSUi,fRSUi.toString());
        storePropToFile(skProp, skFile);
    }

    public static void ASKGen(String pairingFile,String paramsFile,String mskFile,String vectorFile,String skFile,String randomFile,double[] y,int n)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties mskProp = loadPropFromFile(mskFile);
        Properties randomProp =loadPropFromFile(randomFile);
        Element r1 = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element r2 = bp.getZr().newRandomElement().getImmutable();
        String hstr=mskProp.getProperty("h");
        Element h = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(hstr)).getImmutable();
        String h0str=mskProp.getProperty("h0");
        Element h0 = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(h0str)).getImmutable();
        String h1str=mskProp.getProperty("h1");
        Element h1 = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(h1str)).getImmutable();
        String eghstr=mskProp.getProperty("egh");
        String gstr=PProp.getProperty("g");
        Element g = bp.getG2().newElementFromBytes(gstr.getBytes()).getImmutable();
        Element egh = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(eghstr)).getImmutable();
        Element[] yi = new Element[n];
        Double sum = 0.0;
        for (int i = 0; i < n; i++) {
            sum+=Double.valueOf(y[i]);
            yi[i] = bp.getZr().newElementFromBytes(String.valueOf(y[i]).getBytes()).getImmutable();
            vPro.setProperty("y"+i,yi[i].toString());
            skProp.setProperty("y"+i,yi[i].toString());
        }
        Element sum1 = bp.getZr().newElementFromBytes(String.valueOf(String.valueOf(sum)).getBytes()).getImmutable();
        Element ask1 = h0.mulZn(h1.powZn(r1.mulZn(sum1))).getImmutable();
        Element ask2 = h.powZn(r1).getImmutable();
        Element ask3 = egh.powZn(r1).getImmutable();
        Element apk = g.powZn(r2).getImmutable();

        skProp.setProperty("ask1",ask1.toString());
        skProp.setProperty("ask2",ask2.toString());
        skProp.setProperty("ask3",ask3.toString());
        skProp.setProperty("ask4",r2.toString());
        skProp.setProperty("apk",apk.toString());
        storePropToFile(randomProp,randomFile);
        storePropToFile(vPro, vectorFile);
        storePropToFile(skProp, skFile);

    }

    public static void VKGen(String pairingFile,String paramsFile,String mskFile,String skFile,String randomFile,String[] V,int n)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties randomProp =loadPropFromFile(randomFile);
        Properties mskProp = loadPropFromFile(mskFile);

        String gstr=PProp.getProperty("g");
        Element g = bp.getG2().newElementFromBytes(gstr.getBytes()).getImmutable();
        String str = mskProp.getProperty("msk1");
        Element s = bp.getZr().newElementFromBytes(Base64.getDecoder().decode(str)).getImmutable();
        Element[] k = new Element[10], K = new Element[10], c= new Element[10], hV= new Element[10], vsk= new Element[10];
        for (int i = 0; i < 10; i++)
        {
            k[i] = bp.getZr().newRandomElement().getImmutable();
            K[i] = g.powZn(k[i]).getImmutable();
            byte[] bci = sha0(K[i].toString()+V[i]);
            c[i] = bp.getZr().newElementFromHash(bci,0,bci.length).getImmutable();
            byte[] bVi = sha0(V[i]);
            hV[i] = bp.getZr().newElementFromHash(bVi,0,bVi.length).getImmutable();
            vsk[i] = hV[i].powZn(k[i].add(c[i].mulZn(s))).getImmutable();
            skProp.setProperty("vsk"+V[i],vsk.toString());
            randomProp.setProperty("K"+V[i],K[i].toString());
        }


        storePropToFile(skProp, skFile);
        storePropToFile(randomProp, randomFile);

    }

    public static void Authen1(String pairingFile, String paramsFile,String skFile,String randomFile,String[] V,int n)throws NoSuchAlgorithmException {
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties PProp = loadPropFromFile(paramsFile);
        Properties randomProp = loadPropFromFile(randomFile);
        Properties skProp = loadPropFromFile(skFile);
        String apkstr = skProp.getProperty("apk");
        Element apk = bp.getG1().newElementFromBytes(apkstr.getBytes()).getImmutable();
        String ashstr4 = skProp.getProperty("ask4");
        Element ask4 = bp.getZr().newElementFromBytes(ashstr4.getBytes()).getImmutable();
        String gstr=PProp.getProperty("g");
        Element g = bp.getG2().newElementFromBytes(gstr.getBytes()).getImmutable();
        //String Pstr = PProp.getProperty("P");
        //Element P = bp.getZr().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element[] vsk=new Element[10],  t = new Element[10], T = new Element[10], K = new Element[10], c = new Element[10], Q = new Element[10], gamma = new Element[10], B = new Element[10 + 1];
        Element t1 = bp.getZr().newRandomElement().getImmutable();
        Element theta = bp.getZr().newRandomElement().getImmutable();
        for (int i = 0; i < 10; i++) {
            String vskstr = skProp.getProperty("vsk"+V[i]);
            vsk[i] = bp.getG1().newElementFromBytes(vskstr.getBytes()).getImmutable();
            String Kstr = randomProp.getProperty("K" + V[i]);
            t[i] = bp.getZr().newRandomElement().getImmutable();

            byte[] bVi = sha0(V[i]);
            Element hVi = bp.getG1().newElementFromHash(bVi, 0, bVi.length).getImmutable();
            T[i] = hVi.powZn(t[i]).getImmutable();
            K[i] = bp.getG1().newElementFromBytes(Kstr.getBytes()).getImmutable();
            byte[] bci = sha0(K[i].toString() + V[i]);
            c[i] = bp.getZr().newElementFromHash(bci, 0, bci.length).getImmutable();
            //T[i].mulZn(hVi.powZn(t1)), K[i].powZn(ask4).mulZn(P.powZn(ask4.mulZn(c[i])))
            Q[i] = bp.pairing(vsk[i].powZn(t[i].add(t1)),apk).getImmutable();
            byte[] bQi = sha0(Q[i].toString());
            gamma[i] = bp.getZr().newElementFromHash(bQi, 0, bQi.length).getImmutable();

        }
        B[0] = theta;
        for (int i = 1; i < 10; i++) {
            Element sum = bp.getZr().newElement().setToOne();
            for (int j = 0; j < (1 << i); j++) {
                Element product = bp.getZr().newElement().setToOne();
                for (int bit = 0; bit < i; bit++) {
                    if ((j & (1 << bit)) != 0) {
                        product = product.mulZn(gamma[bit]).getImmutable();
                    }
                }
                sum = sum.add(product);
            }
            B[i] = sum.negate();
        }
        Element t2 = bp.getZr().newRandomElement().getImmutable();
        Element T2 = g.powZn(t2).getImmutable();
        Element sum1=bp.getZr().newElement().setToZero();
        for (int i = 0; i < 10; i++)
        {
            sum1 = sum1.add(B[i]).getImmutable();
        }
        byte[] bh4 = sha0(T2.toString()+theta.toString()+sum1.toString());
        Element h4 = bp.getG1().newElementFromHash(bh4, 0, bh4.length).getImmutable();
        Element sigma = h4.mulZn(t2.add(theta)).add(h4.mulZn(ask4)).getImmutable();
        randomProp.setProperty("sigma",sigma.toString());
        randomProp.setProperty("Bsum",sum1.toString());
        for (int i = 0; i <10; i++)
        {
            randomProp.setProperty("b"+i,B[i].toString());
            randomProp.setProperty("t"+V[i],t[i].toString());
        }
        randomProp.setProperty("t1",t1.toString());
        randomProp.setProperty("T2",T2.toString());
        storePropToFile(randomProp, randomFile);
    }
    public static void Authen2(String pairingFile,String paramsFile,String skFile,String randomFile, String Vi,int n)throws NoSuchAlgorithmException
    {
        Properties PProp = loadPropFromFile(paramsFile);
        Pairing bp = PairingFactory.getPairing(pairingFile);
        Properties randomProp = loadPropFromFile(randomFile);
        Properties skProp = loadPropFromFile(skFile);
        String apkstr = skProp.getProperty("apk");
        Element apk = bp.getG1().newElementFromBytes(apkstr.getBytes()).getImmutable();
        String Bstr = randomProp.getProperty("Bsum");
        Element Bsum = bp.getG1().newElementFromBytes(Bstr.getBytes()).getImmutable();
        String sigmastr = randomProp.getProperty("sigma");
        Element sigma = bp.getG1().newElementFromBytes(sigmastr.getBytes()).getImmutable();
        String T2str = randomProp.getProperty("T2");
        Element T2 = bp.getG1().newElementFromBytes(T2str.getBytes()).getImmutable();
        String vskstr = skProp.getProperty("vsk"+Vi);
        Element vsk = bp.getG1().newElementFromBytes(vskstr.getBytes()).getImmutable();
        String tistr = randomProp.getProperty("t"+Vi);
        Element ti = bp.getG1().newElementFromBytes(tistr.getBytes()).getImmutable();
        String t1str = randomProp.getProperty("t1");
        Element t1 = bp.getG1().newElementFromBytes(t1str.getBytes()).getImmutable();
        Element Q = bp.pairing(vsk.powZn(ti.add(t1)),apk).getImmutable();
        String gstr=PProp.getProperty("g");
        Element g = bp.getG2().newElementFromBytes(gstr.getBytes()).getImmutable();
        byte[] bgammai = sha0(Q.toString());
        Element gamma = bp.getZr().newElementFromHash(bgammai, 0, bgammai.length).getImmutable();
        Element[] B = new Element[n];
        String bstr = randomProp.getProperty("b"+0);
        B[0] = bp.getZr().newElementFromBytes(bstr.getBytes()).getImmutable();
        Element f = B[0];
        for (int i = 1; i < 10; i++)
        {
            String bstr1 = randomProp.getProperty("b"+i);
            B[i] = bp.getZr().newElementFromBytes(bstr1.getBytes()).getImmutable();
            f = f.add(B[i].mulZn(gamma)).getImmutable();
            gamma = gamma.mulZn(gamma);
        }
        byte[] bh4 = sha0(T2.toString()+f.toString()+Bsum.toString());
        Element h4 = bp.getZr().newElementFromHash(bh4, 0, bh4.length).getImmutable();
        Element sigmai = T2.powZn(h4).mulZn(g.powZn(h4.mulZn(f))).mulZn(apk.powZn(h4)).getImmutable();
        if (g.powZn(sigma).equals(sigmai))
            out.println("success!" +"      "+ g.powZn(sigma).toString() + "      "+ sigmai );
    }
    public static void Encryption(String pairingFile, String paramsFile, String vectorFile, String CTFile,int n, double[] x, String Vi) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Element z = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String egh0str=PProp.getProperty("egh0");
        Element egh0 = bp.getGT().newElementFromBytes(egh0str.getBytes()).getImmutable();
        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();

        Element C1 = g.powZn(z).getImmutable();
        Element C2 = g1.powZn(z).getImmutable();
        for (int i = 0; i < n; i++)
            C2 = C2.mulZn(g.powZn(bp.getG1().newElementFromBytes(String.valueOf(x[i]).getBytes()).getImmutable()));
        Element C3 = egh0.powZn(z).getImmutable();
        CTProp.setProperty("C1"+Vi,C1.toString());
        CTProp.setProperty("C2"+Vi,C2.toString());
        CTProp.setProperty("C3"+Vi,C3.toString());
        for (int i = 0; i < n; i++)

            vPro.setProperty("x"+i+Vi,String.valueOf(x[i]));



        storePropToFile(CTProp,CTFile);
        storePropToFile(vPro, vectorFile);

    }

    public static void AggEnc(String pairingFile, String CTFile,int n,  String[] V) throws NoSuchAlgorithmException {
        Properties CTProp =loadPropFromFile(CTFile);
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Element C1 = bp.getG1().newElement().setToZero();
        Element C2 = bp.getG1().newElement().setToZero();
        Element C3 = bp.getGT().newElement().setToZero();
        for (int i = 0; i<10; i++)
        {
            String ci1 = CTProp.getProperty("C1"+V[i]);
            String ci2 = CTProp.getProperty("C2"+V[i]);
            String ci3 = CTProp.getProperty("C3"+V[i]);
            C1 = C1.mulZn(bp.getG1().newElementFromBytes(ci1.getBytes()).getImmutable());
            C2 = C2.mulZn(bp.getG1().newElementFromBytes(ci2.getBytes()).getImmutable());
            C3 = C3.mulZn(bp.getGT().newElementFromBytes(ci3.getBytes()).getImmutable());
        }
        CTProp.setProperty("C1",C1.toString());
        CTProp.setProperty("C2",C2.toString());
        CTProp.setProperty("C3",C3.toString());
        storePropToFile(CTProp,CTFile);
    }




    public static void Dec(String pairingFile,String paramsFile,String vectorFile,String skFile,String randomFile,String CTFile,int n, Double M)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomProp =loadPropFromFile(randomFile);
        String C1str=CTProp.getProperty("C1");
        Element C1 = bp.getG1().newElementFromBytes(C1str.getBytes()).getImmutable();
        String C2str=CTProp.getProperty("C2");
        Element C2 = bp.getG1().newElementFromBytes(C2str.getBytes()).getImmutable();
        String C3str=CTProp.getProperty("C3");
        Element C3 = bp.getGT().newElementFromBytes(C3str.getBytes()).getImmutable();
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String askstr1 = skProp.getProperty("ask1");
        Element ask1 = bp.getG1().newElementFromBytes(askstr1.getBytes()).getImmutable();
        String askstr2=skProp.getProperty("ask2");
        Element ask2 = bp.getG1().newElementFromBytes(askstr2.getBytes()).getImmutable();
        String askstr3 = skProp.getProperty("ask3");
        Element ask3 = bp.getGT().newElementFromBytes(askstr3.getBytes()).getImmutable();
        Element[] y = new Element[n];
        for (int i = 0; i < n; i++)
            y[i] = bp.getZr().newElementFromBytes(vPro.getProperty("y"+i).getBytes()).getImmutable();
        Element D = bp.pairing(C1,ask1).negate().mulZn(C3).getImmutable();
        C2 = C2.powZn(y[0]).getImmutable();
        for (int i = 1; i < n; i++)
            C2 = C2.mulZn(C2.powZn(y[i])).getImmutable();
        D = D.mulZn(bp.pairing(C2,ask2)).getImmutable();

        Element EM = ask3.powZn(bp.getZr().newElementFromBytes(String.valueOf(M).getBytes()).getImmutable());
        if (D.isEqual(EM)) out.println("OK");

    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        int n = 50, t =5;
        double[] xsum = new double[n];
        long start = System.currentTimeMillis();
        String dir = "./storeFile/Ours_File/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String ParameterFileName = dir + "params.properties";
        String mskFileName = dir + "msk.properties";
        String vectorFileName=dir+"vector.properties";

        String randomFileName=dir+"random.properties";
        String skFileName=dir+"sk.properties";
        String CTFileName=dir+"CT.properties";
        String[] RSU = new String[t], V = new String[10];

        Random rand = new Random();
        for (int i = 0; i < t; i++)
        {
            RSU[i] = getRandomString(10);


        }
        for (int i = 0; i < 10; i++)

            V[i] = getRandomString(10);





        double[] y = new double[n];


        for (int i = 0; i < n; i++)

            y[i] = rand.nextInt(5)+0;

        long start1 = System.currentTimeMillis();
        setup(pairingParametersFileName,ParameterFileName,mskFileName,t);
        long end1 = System.currentTimeMillis();
        out.println("KGC-Setup");
        out.println(end1-start1);
        long start2 = System.currentTimeMillis();
        setup1(pairingParametersFileName, ParameterFileName,mskFileName);
        long end2 = System.currentTimeMillis();

        //Encryption( pairingParametersFileName, ParameterFileName, vectorFileName, CTFileName, randomFileName, ID, n, x);
        //System.out.println("Enc");
        out.println("PKG-Setup");
        out.println(end2-start2);
        long start3 = System.currentTimeMillis();
        RSUKGen(pairingParametersFileName, ParameterFileName,mskFileName,RSU[0],skFileName,t);
        //KGen(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,ID,n);
        long end3 = System.currentTimeMillis();
        out.println("RSUKGen");
        out.println(end3-start3);
        long start4 = System.currentTimeMillis();
        ASKGen(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,n);
       // Update(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,ID1,n);
         long end4 = System.currentTimeMillis();
        out.println("ASKGen");
        out.println(end4-start4);
        long start5 = System.currentTimeMillis();
        VKGen(pairingParametersFileName,ParameterFileName,mskFileName,skFileName,randomFileName,V,n);
        long end5 = System.currentTimeMillis();
        out.println("VKGen");
        out.println(end5-start5);
        long start6 = System.currentTimeMillis();
        Authen1(pairingParametersFileName, ParameterFileName,skFileName,randomFileName,V,n);
        long end6 = System.currentTimeMillis();
        out.println("Authen1");
        out.println(end6-start6);

        for (int i = 0; i <10; i++)
        {
            long start7 = System.currentTimeMillis();
            Authen2(pairingParametersFileName,ParameterFileName,skFileName,randomFileName,V[i],n);
            long end7 = System.currentTimeMillis();
            out.println("Authen2"+V[i]);
            out.println(end7-start7);
        }
        for (int i = 0; i < 10; i++)
        {
            double[] x = new double[n];
            for (int j = 0; j < n; j++)
            {
                x[j] = rand.nextInt(5)+0;
                xsum[j]+=x[j];
            }
            long start8 = System.currentTimeMillis();
            Encryption(pairingParametersFileName, ParameterFileName, vectorFileName, CTFileName,n,  x,  V[i]);
            long end8 = System.currentTimeMillis();
            out.println("Enc"+V[i]);
            out.println(end8-start8);
        }
        long start9 = System.currentTimeMillis();
        AggEnc(pairingParametersFileName, CTFileName, n, V);
        long end9 = System.currentTimeMillis();
        out.println("AggEnc");
        out.println(end9-start9);
        Double sum = 0.0;
        for (int i = 0; i < n; i++)
            sum+=xsum[i]*y[i];
        long start10 = System.currentTimeMillis();
        Dec(pairingParametersFileName,ParameterFileName,vectorFileName,skFileName,randomFileName,CTFileName,n,sum);
        long end10 = System.currentTimeMillis();
        System.out.println("Dec");
        System.out.println(end10-start10);

        //long end = System.currentTimeMillis();
        //System.out.println(end-start);
    }

    public  static String getRandomString(int length){
        String str = "abcdefghijklmnopqrstuvwxyZABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++)
        {
            int number = random.nextInt(62);
            sb.append(str.charAt(number));
        }
        return sb.toString();
    }


}
